# Purpose
The purpose of this repository is to store the Python in Heliophysics Community (PyHC) Standards. 
This is the canonical version.
